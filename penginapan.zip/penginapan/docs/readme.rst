.. include:: ../README.rst

Karinov Media Network 
==================
- https://karinov.co.id - jasa digital marketing indonesia
- https://www.tnol.co.id - forum modifikasi otomotif indonesia
- https://blogs.itb.ac.id/wikia - catatan hidup mahasiswa wikia alfa
- https://blogs.itb.ac.id/feeds - kumpulan tautan berita terbaru indonesia
- https://www.autobild.co.id/ - direktori service center dan brand ternama Indonesia
